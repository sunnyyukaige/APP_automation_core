# APP-automation-python
framework and implementation for APP for both IOS&amp;Android
# installation:
## •	Install the Java JDK and set JAVA_HOME to your JDK’s bin folder.
## •	Install the Android SDK. You will need to run the 'android’ tool (included in the SDK, in the tools folder) and make sure you have an API Level 17 or greater API installed. Set ANDROID_HOME to be your Android SDK path and add the tools and platform-tools folders to your PATH variable
## •	Install node.js (v.0.12 or greater). Use the installer from https://nodejs.org/en/
## •	Install appium using (
$ npm install -g appium
$ appium
)
## •	install python from https://www.python.org/, and set root folder to your PATH variable using
          ( 
          $  python   
           ) 
           check install successful
## •	Install appium python client (use command  python setup.py install )
## •	Install Genymotion from https://www.genymotion.com/  and  add Google Nexus 6P - 6.0.0 - API 23 - 1440x2560 virtual device

 
 -------------------------------华丽分界线------------------------------------------------------  

