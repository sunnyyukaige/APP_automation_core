from appium.webdriver.common.mobileby import MobileBy


class By(MobileBy):
    pass
